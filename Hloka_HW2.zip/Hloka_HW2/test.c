#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <limits.h>

typedef int MYFUNC(char *dir,char *gname);
int opfunc(char *dir,char *gname, MYFUNC *f) {
	return f(dir, gname);
}

typedef int MYFUNC1(char *dir,char *gname,int size);
int opfunc1(char *dir,char *gname,int size, MYFUNC1 *f) {
	return f(dir, gname,size);
}

typedef int MYFUNC2(char *dir,char *gname,char *type);
int opfunc2(char *dir,char *gname,char *type, MYFUNC2 *f) {
	return f(dir, gname,type);
}
int RecursiveDirectory(char *dir,char *gname);
int RecursiveDirectory_back(char *dir,char *gname);
int RecursiveDirectorydetails(char *dir,char *gname);
int RecursiveDirectorysize(char *dir,char *gname,int size);
int RecursiveDirectorytype(char *dir,char *gname,int type);
int RecursiveDirectoryfile(char *dir,char *gname,char *type);
void printFileProperties(struct stat stats,int sz)
{
    struct tm dt;
    char str[80]="";
    if (stats.st_mode & R_OK)
       strcat(str, "read ");
    if (stats.st_mode & W_OK)
        strcat(str,"write ");
    if (stats.st_mode & X_OK)
        strcat(str, "execute");
    dt = *(gmtime(&stats.st_mtime));
    if(sz>=stats.st_size)
    {
	
    printf("( %s %ld %d-%d-%d %d:%d:%d)\n", str,stats.st_size,dt.tm_mday, dt.tm_mon, dt.tm_year + 1900, 
                                              dt.tm_hour, dt.tm_min, dt.tm_sec);
	}
	else{
	printf("\n");
	}
}

int main(int argc, char *argv[]) {
   int option;
   int optionsval=0;
   int options=0;
   int optiontval=0;
   int optiont=0;
   char optionSval[40]=".";
   int optionS=0;
   char optionfval[40]=".";
   int optionf=0;
   char *ipdir;
	  if (argc < 2) 
	  { 
	   argv[1]=".";
	   ipdir=".";
	   opfunc(argv[1], argv[1], RecursiveDirectory_back);
	   return 1;
	  } 
	  	
	  
   while((option = getopt(argc, argv, ":S:s:f:t:l")) != -1){ 
      switch(option)
	  {	
         case 'S':
         
           
            optionS=1;
            if(optarg == NULL)
            {
             strcpy(optionSval,".");
             printf("%s",optionSval);
             break;
         	}
            strcpy(optionSval,optarg);
            printf("%s",optionSval);
            
            break;
        case 's':
            
           	options=1;
           	optionsval=atoi(optarg);
            break;
         case 'f': 
             
            optionf=1;
            strcpy(optionfval,optarg);
            break;
        case 't':
            
           	optiont=1;
           	if(strcmp(optarg,"d")!=0)
           	optiontval=1;
           	else
           	optiontval=0;
            break;
            
         case ':':
            opfunc(".", ".", RecursiveDirectorydetails);
            return 0;
            break;
         case '?': 
            printf("unknown option: %c\n", optopt);
            break;
      }
      
   }
   if (optind < argc)
  {
    strcpy(optionSval,argv[optind]);
  }
   if(options==1 && optionS==1)
   {
   	
   	opfunc1(optionSval,optionSval,optionsval,RecursiveDirectorysize);
   	
   	return 1;
   }
   if(optiont==1 && optionS==1)
   {
   
   	opfunc1(optionSval,optionSval,optiontval,RecursiveDirectorytype);
   
   	return 1;
   }
   
   if(optionf==1 && optionS==1)
   {
   	printf("hi");
   	opfunc2(optionSval,optionSval,optionfval,RecursiveDirectoryfile);
   
   	return 1;
   }
   
   else if(options==1)
   {
   	printf("%d",optionsval);
   	opfunc1(optionSval,optionSval,optionsval,RecursiveDirectorysize);
   	
   	return 1;
   }
   else  if(optionS==1)
   {
   	opfunc(optionSval,optionSval,RecursiveDirectorydetails);
   	
   	return 1;
   }
   else if(optiont==1)
   {
   	opfunc1(optionSval,optionSval,optiontval,RecursiveDirectorytype);
   	
   	return 1;
   }
   else if(optionf==1)
   {
   	opfunc2(optionSval,optionSval,optionfval,RecursiveDirectoryfile);
   	
   	return 1;
   }
   printf("%s",argv[optind]);
   opfunc(argv[optind],argv[optind],RecursiveDirectory);
   
   return 1;
}

int RecursiveDirectory(char *dir,char *gname)
{
	
	  struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'\n", dir); 
	    exit (-1);
	  } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
	  	if(strcmp(dir, gname) != 0)
					printf("\t");
	    printf ("%s\n",  (*dirent).d_name); 
	    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
	   		{
	   			
	   			char subdir[99] = { 0 };
				strcat(subdir, dir);
				strcat(subdir, "/");
				strcat(subdir, dirent->d_name);
				printf("\n\t%s\n",subdir);
	   			RecursiveDirectory(subdir,gname);
	   			printf("\n");
	   		
			}
			
	    count++; 
	  } 
	  closedir (parentDir); 
	  return 0; 	
}
int RecursiveDirectory_back(char *dir,char *gname)
{
	
	  struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'\n", dir); 
	    exit (-1);
	  } 
	  char predir[100];
   if (getcwd(predir, sizeof(predir)) != NULL) {
   	strcat(predir,dir);
       printf("%s\n", predir);
   } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
	  	if(strcmp(dir, gname) != 0)
					printf("\t");
	    printf (" %s",  (*dirent).d_name); 
	    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
	   		{
	   			
	   			char subdir[99] = { 0 };
				strcat(subdir, dir);
				strcat(subdir, "/");
				strcat(subdir, dirent->d_name);
				printf("\n\t%s\n",subdir);
	   			RecursiveDirectory_back(subdir,gname);
	   			printf("\n");
	   		
			}
			
	    count++; 
	  } 
	  closedir (parentDir); 
	  return 0; 	
}
int RecursiveDirectorydetails(char *dir,char *gname)
{
	
	  struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'", dir); 
	    exit (-1);
	  } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
		    
		    if(strcmp(dir, gname) != 0)
		  	{
			
				printf("\t");
				
			}
			printf ("%s", dirent->d_name);
		    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
		   		{
		   			
		   			char subdir[99] = { 0 };
					strcat(subdir, dir);
					strcat(subdir, "/");
					strcat(subdir, dirent->d_name);
					printf("\n\t%s\n",subdir);
		   			RecursiveDirectorydetails(subdir,gname);
		   			printf("\n");
		   		
				}
			struct stat stats;
			char *str=dir;
			
			int r= stat(dirent->d_name, &stats)	;
			if (r == 0)
		    {
		    	
		        printFileProperties(stats,999999);
		    }
		    else
		    {
		    	//printf("\n%s hi %s ",dirent->d_name,dir);
		    	printf("\n");
			}
		   
		    
		    count++; 
		} 
	  closedir (parentDir); 
	  return 0; 	
}
int RecursiveDirectorysize(char *dir,char *gname,int size)
{
	
	  struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'", dir); 
	    exit (-1);
	  } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
		    
		    if(strcmp(dir, gname) != 0)
		  	{
			
				printf("\t");
				
			}
			if(dirent->d_type  == DT_REG )
			{
				struct stat st;
				stat(dirent->d_name, &st);
				int len=st.st_size;
				if(len>=size)
				{
						printf ("%s",  dirent->d_name);
				}
			}
			if(dirent->d_type  == DT_DIR )
			{
					printf ("%s",  dirent->d_name);
				
			}
		
		
		    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
		   		{
		   			
		   			char subdir[99] = { 0 };
					strcat(subdir, dir);
					strcat(subdir, "/");
					strcat(subdir, dirent->d_name);
					printf("\n\t%s\n",subdir);
		   			RecursiveDirectorysize(subdir,gname,size);
		   			printf("\n");
		   		
				}
			struct stat stats;
			 	
			if (stat(dirent->d_name, &stats) == 0)
		    {
		    	
		        printFileProperties(stats,size);
		    }
		    else
		    {
		    	printf("\n");
			}
		   
		    
		    count++; 
		} 
	  closedir (parentDir); 
	  return 0; 	
}
int RecursiveDirectorytype(char *dir,char *gname,int type)
{
	struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'", dir); 
	    exit (-1);
	  } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
		    
		    if(strcmp(dir, gname) != 0)
		  	{
			
				printf("\t");
				
			}
			if(dirent->d_type  == DT_REG  && type==1)
			{
				
						printf ("%s\n",  dirent->d_name);
				
			}
			if(dirent->d_type  == DT_DIR && type==0)
			{
					printf ("%s\n",  dirent->d_name);
				
			}
		
		
		    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
		   		{
		   			
		   			char subdir[99] = { 0 };
					strcat(subdir, dir);
					strcat(subdir, "/");
					strcat(subdir, dirent->d_name);
					printf("\n\t%s\n",subdir);
		   			RecursiveDirectorytype(subdir,gname,type);
		   			printf("\n");
		   		
				}
			struct stat stats;
			 	
			
		   
		    
		    count++; 
		} 
	  closedir (parentDir); 
	  return 0; 	
}
int RecursiveDirectoryfile(char *dir,char *gname,char *type)
{
	struct dirent *dirent; 
	  DIR *parentDir; 
	  parentDir = opendir (dir); 
	  if (parentDir == NULL) 
	  { 
	    printf ("Error opening directory '%s'", dir); 
	    exit (-1);
	  } 
	  int count = 1; 
	  while((dirent = readdir(parentDir)) != NULL)
	  { 
		    
		    if(strcmp(dir, gname) != 0)
		  	{
			
				printf("\t");
				
			}
			if(dirent->d_type  == DT_REG )
			{
						if(strstr(dirent->d_name, type) != NULL)	
						printf ("%s\n",  dirent->d_name);
				
			}
			if(dirent->d_type  == DT_DIR)
			{
					printf (" %s\n",  dirent->d_name);
				
			}
		
		
		    if (strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0 && dirent->d_type  == DT_DIR )
		   		{
		   			
		   			char subdir[99] = { 0 };
					strcat(subdir, dir);
					strcat(subdir, "/");
					strcat(subdir, dirent->d_name);
					printf("\n\t%s\n",subdir);
		   			RecursiveDirectoryfile(subdir,gname,type);
		   			printf("\n");
		   		
				}
			struct stat stats;
			 	
			
		   
		    
		    count++; 
		} 
	  closedir (parentDir); 
	  return 0; 	

}
